In order to play Numbrix, please follow these three simple steps:

1. Compile Numbrix

(Do this from the directory where you untarred all of the .java source files)

javac *.java

2. Run Numbrix

java Numbrix

3. Follow the in-game instructions

Have fun! :)
