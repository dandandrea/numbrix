import java.lang.Exception;

public class BoardException extends NumbrixException {
    public BoardException(String message) {
        super(message);
    }
}
