import java.lang.Exception;

public class NumbrixException extends Exception {
    public NumbrixException(String message) {
        super(message);
    }
}
