import java.lang.Exception;

public class IllegalInputFormatException extends NumbrixException {
    public IllegalInputFormatException(String message) {
        super(message);
    }
}
